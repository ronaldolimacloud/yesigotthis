const { DynamoDBClient, ScanCommand } = require('@aws-sdk/client-dynamodb');
const { unmarshall } = require('@aws-sdk/util-dynamodb');

const ddb = new DynamoDBClient({ region: 'ap-southeast-2' });

exports.handler = async (event) => {
   try {
       const command = new ScanCommand({
           TableName: 'yesigotthis-content'
       });
       
       const response = await ddb.send(command);
       const items = response.Items.map(item => unmarshall(item));
       
       return {
           statusCode: 200,
           headers: {
               "Content-Type": "application/json",
               "Access-Control-Allow-Origin": "*"
           },
           body: JSON.stringify(items)
       };
   } catch (error) {
       console.error('Error:', error);
       return {
           statusCode: 500,
           body: JSON.stringify({ error: error.message })
       };
   }
};